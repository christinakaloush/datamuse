# A small program using the Datamuse API

## Description

Welcome to the Datamuse API! This program allows you to type in any sequence of letters and question
marks to determine words that match your query along with their definitions. For example, 
if you're looking for words that start with an h and end with a p, type h??p.